import React from 'react';
import './App.css';
import VirtualizedList from './VirtualizedList';

function App() {
  const specifiedNumbers = [
    101, 232, 343, 454, 565,
    676, 787, 898, 909, 112,
    223, 334, 445, 556, 667,
    778, 889, 990, 111, 222,
    333, 444, 555, 666, 777,
    888, 999, 121, 232, 343,
    454, 565, 676, 787, 898,
    909, 1010, 1111, 1212, 1313,
    1414, 1515, 1616, 1717, 1818,
    1919, 2020, 2121, 2222, 2323,
  ];

  return (
    <div className="App p-8 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-8 text-center">Virtualized List Project</h1>
      <div className="bg-white rounded-lg shadow-lg p-4">
        <VirtualizedList data={specifiedNumbers} />
      </div>
    </div>
  );
}

export default App;
