import { useState } from 'react';
import './VirtualizedList.css';

const itemHeight = 35; // Height of each item
const windowHeight = 500; // Height of the visible window
const overscan = 5; // Number of extra items to render

interface VirtualizedListProps {
  numberOfItems: number;
}

export const VirtualizedList = ({ numberOfItems }: VirtualizedListProps) => {
  const [scrollTop, setScrollTop] = useState(0);
  
  // Calculate the range of items to render
  const startIndex = Math.max(0, Math.floor(scrollTop / itemHeight) - overscan);
  const visibleItems = Math.ceil(windowHeight / itemHeight);
  const endIndex = Math.min(
    numberOfItems,
    startIndex + visibleItems + overscan * 2
  );

  const generateRows = () => {
    let items: JSX.Element[] = [];
    for (let i = startIndex; i < endIndex; i++) {
      items.push(<ListItem key={i} index={i} />);
    }
    return items;
  };

  return (
    <div
      className="virtualized-list-container"
      style={{ height: `${windowHeight}px` }}
      onScroll={(e) => {
        setScrollTop(e.currentTarget.scrollTop);
      }}
    >
      <div
        className="virtualized-list-inner"
        style={{
          height: `${numberOfItems * itemHeight}px`,
          position: 'relative'
        }}
      >
        {generateRows()}
      </div>
    </div>
  );
};

const ListItem = ({ index }: { index: number }) => {
  return (
    <div
      className="virtualized-list-item"
      style={{
        height: `${itemHeight}px`,
        top: `${itemHeight * index}px`,
        backgroundColor: index % 2 === 0 ? '#f0f0f0' : '#ffffff',
        position: 'absolute',
        width: '100%',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        borderBottom: '1px solid #e2e8f0'
      }}
    >
      List Item Index - {index}
    </div>
  );
};

export default VirtualizedList;
