import React from 'react';
import VirtualizedList from './VirtualizedList';
import './App.css';

function App() {
  return (
    <div className="app-container">
      <h1 className="app-title">Virtualized List Project</h1>
      <div className="app-content">
        <VirtualizedList numberOfItems={1000} />
      </div>
    </div>
  );
}

export default App;
