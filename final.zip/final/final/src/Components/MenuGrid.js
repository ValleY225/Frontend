import React from "react";
import menuItems from "./Data";
import MenuItem from "./MenuItem";
import "../Style/Container.css";

const MenuGrid = () => {
  // Dynamically derive unique categories from the data
  const categories = [...new Set(menuItems.map((item) => item.category))];

  return (
    <section className="menu-grid">
      {categories.map((category) => (
        <div key={category} id={category} className="menu-category">
          <h2>{category.charAt(0).toUpperCase() + category.slice(1)}</h2>
          {menuItems
            .filter((item) => item.category === category)
            .map((item) => (
              <MenuItem key={item.id} item={item} />
            ))}
        </div>
      ))}
    </section>
  );
};

export default MenuGrid;
