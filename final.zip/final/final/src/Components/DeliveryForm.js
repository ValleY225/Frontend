import React, { useEffect, useState, useRef } from "react";
import "../Style/Form.css";

const loadGoogleMapsScript = (callback) => {
  if (window.google && window.google.maps) {
    callback();
    return;
  }
  const script = document.createElement("script");
  script.src = `https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&libraries=places`;
  script.async = true;
  script.defer = true;
  script.onload = callback;
  document.head.appendChild(script);
};

const DeliveryForm = ({ onClose }) => {
  const [address, setAddress] = useState("");
  const [phone, setPhone] = useState("");
  const [courierInfo, setCourierInfo] = useState("");

  const addressInputRef = useRef(null);

  useEffect(() => {
    loadGoogleMapsScript(() => {
      if (window.google) {
        const autocomplete = new window.google.maps.places.Autocomplete(
          addressInputRef.current,
          { types: ["geocode"] }
        );
        autocomplete.addListener("place_changed", () => {
          const place = autocomplete.getPlace();
          setAddress(place.formatted_address);
        });
      }
    });
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    alert(`Order placed for:
Address: ${address}
Phone: ${phone}
Courier Notes: ${courierInfo}`);
    onClose();
  };

  return (
    <div className="form-container">
      <h2>Delivery Order</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Enter your address"
          ref={addressInputRef}
          value={address}
          onChange={(e) => setAddress(e.target.value)}
          required
        />
        <input
          type="tel"
          placeholder="Enter your phone number"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          required
        />
        <input
          type="text"
          placeholder="Enter information for courier"
          value={courierInfo}
          onChange={(e) => setCourierInfo(e.target.value)}
        />
        <button type="submit">Order</button>
        <button type="button" onClick={onClose}>
          Cancel
        </button>
      </form>
    </div>
  );
};

export default DeliveryForm;
