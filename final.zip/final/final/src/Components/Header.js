import React, { useState } from "react";
import "../Style/Header.css";
import logo from "../Photos/logo.jpg";
import Modal from "./Modal";
import DeliveryForm from "./DeliveryForm";
import ReservationForm from "./ReservationForm";

const Header = () => {
  const [showDelivery, setShowDelivery] = useState(false);
  const [showReservation, setShowReservation] = useState(false);

  return (
    <header className="Header">
      <div className="logo-container">
        <img src={logo} alt="Company logo" className="logo" />
      </div>

      <nav className="nav-buttons">
        <button className="primary-btn" onClick={() => setShowDelivery(true)}>
          Order Delivery
        </button>
        <button className="primary-btn" onClick={() => setShowReservation(true)}>
          Reserve Table
        </button>
      </nav>

      {/* Delivery Form Modal */}
      <Modal isOpen={showDelivery} onClose={() => setShowDelivery(false)}>
        <DeliveryForm onClose={() => setShowDelivery(false)} />
      </Modal>

      {/* Reservation Form Modal */}
      <Modal isOpen={showReservation} onClose={() => setShowReservation(false)}>
        <ReservationForm onClose={() => setShowReservation(false)} />
      </Modal>
    </header>
  );
};

export default Header;
