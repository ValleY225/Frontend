import React from "react";
import "../Style/Item.css";

const MenuItem = ({ item }) => {
  return (
    <div className="menu-item">
      <img src={item.image} alt={item.name} className="menu-item-image" />
      <div className="menu-item-info">
        <h3>{item.name}</h3>
        <p>{item.description}</p>
        <div className="menu-item-footer">
          <span>${item.price.toFixed(2)}</span>
          <button className="add-btn">Add</button>
        </div>
      </div>
    </div>
  );
};

export default MenuItem;
