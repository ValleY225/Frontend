import React from 'react';
import '../Style/Header.css';
import logo from '../Photos/logo.jpg';

const Header = () => {
  return (
    <header className='Header'>
      <div className="logo-container">
        <img src={logo} alt='logo' className="logo" />

      </div>
    </header>
  );
};

export default Header;

