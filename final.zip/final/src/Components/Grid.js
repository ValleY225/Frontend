// MenuGrid.jsx
import React from "react";
import menuItems from './Data';
import MenuItem from "./Item";
import '../Style/Container.css';

const MenuGrid = () => {
  return (
    <section className="MenuGrid">
      <div id="pizzas" className="menu-category">
        <h2>Pizzas</h2>
        {menuItems.filter(item => item.category === 'pizzas').map(item => (
          <MenuItem key={item.id} item={item} />
        ))}
      </div>
      <div id="hot-meals" className="menu-category">
        <h2>Hot Meals</h2>
        {menuItems.filter(item => item.category === 'hot-meals').map(item => (
          <MenuItem key={item.id} item={item} />
        ))}
      </div>
      <div id="drinks" className="menu-category">
        <h2>Drinks</h2>
        {menuItems.filter(item => item.category === 'drinks').map(item => (
          <MenuItem key={item.id} item={item} />
        ))}
      </div>
      <div id="desserts" className="menu-category">
        <h2>Desserts</h2>
        {menuItems.filter(item => item.category === 'desserts').map(item => (
          <MenuItem key={item.id} item={item} />
        ))}
      </div>
    </section>
  );
};


export default MenuGrid;

