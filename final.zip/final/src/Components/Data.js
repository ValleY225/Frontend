import Mar from '../Photos/Mar.jpg';
import Pep from '../Photos/Pep.jpg';
import Veg from '../Photos/veg.jpg';

const menuItems = [
  { 
    id: 1,
    category: 'pizzas',
    name: 'Margherita Pizza',
    description: 'Classic delight with fresh tomatoes, basil, and mozzarella cheese.',
    price: 9.99,
    image: Mar,
  },
  {
    id: 2,
    category: 'pizzas',
    name: 'Pepperoni Pizza',
    description: 'Loaded with pepperoni and extra cheese for a spicy kick.',
    price: 12.99,
    image: Pep,
  },
  {
    id: 3,
    category: 'pizzas',
    name: 'Veggie Delight',
    description: 'A mix of fresh vegetables, herbs, and a light tomato sauce.',
    price: 10.99,
    image: Veg,
  }
];

export default menuItems;
