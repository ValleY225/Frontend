import React from 'react';
import '../Style/Navbar.css';

const Navbar = () => {
  // Function to scroll smoothly and remove focus from the button after click
  const handleClick = (sectionId, e) => {
    e.target.blur(); // Remove focus so hover/active style doesn't persist
    const section = document.getElementById(sectionId);
    if (section) {
      section.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <aside className="Navbar">
      <nav className="nav-categories">
        <button className="nav-btn" onClick={(e) => handleClick('pizzas', e)}>Pizzas</button>
        <button className="nav-btn" onClick={(e) => handleClick('hot-meals', e)}>Hot Meals</button>
        <button className="nav-btn" onClick={(e) => handleClick('drinks', e)}>Drinks</button>
        <button className="nav-btn" onClick={(e) => handleClick('desserts', e)}>Desserts</button>
      </nav>
    </aside>
  );
};



export default Navbar;
