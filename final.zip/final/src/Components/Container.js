import '../Style/Container.css'
import React from 'react';
import Header from './Head'; // Adjust path if needed
import MenuGrid from './Grid';
import Navbar from './Navbar';


function App() {
  return (
    <div className="container">
      <Header /> 
      <MenuGrid />
      <Navbar />
    </div>
  );
}

export default App;
