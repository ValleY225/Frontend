import React from 'react';

/*
 * Display Component
 * Renders two rows:
 * - Top row: shows the current expression (numbers and operators) aligned to the left.
 * - Bottom row: shows the computed result aligned to the right.
 */
const Display = ({ input, result }) => {
  return (
    <div className="display">
      <div className="display-top">{input}</div>
      <div className="display-bottom">{result}</div>
    </div>
  );
};

export default Display;
