import React, { useState , useEffect } from 'react';
import Display from './Display';
import './App.css';

// Values and their default position
const Calculator = () => {
  const [calc, setCalc] = useState({
    num: "",
    operator: null,
    result: 0,
  });

  // Handler for general button clicks (numbers, operators, clear)
  const handleClick = (buttonValue) => {
    if (buttonValue === "C") {
      setCalc({ num: "", operator: null, result: 0 });
      return;
    }
    // If an operator is pressed, store current number and operator
    if (["+", "-", "*", "/"].includes(buttonValue)) {
      if (calc.num !== "") {
        setCalc({
          result: parseFloat(calc.num),
          operator: buttonValue,
          num: "",
        });
      }
      return;
    }
    // Append number or decimal point
    setCalc({
      ...calc,
      num: calc.num + buttonValue,
    });
  };
      //C:\Users\user\OneDrive\Desktop\Frontend\Calculator\my-app
  // Separate equals handler function
  const handleEqual = () => {
    if (calc.operator && calc.num !== "") {
      const current = parseFloat(calc.num);
      let computed = calc.result;
      switch (calc.operator) {
        case "+":
          computed += current;
          break;
        case "-":
          computed -= current;
          break;
        case "*":
          computed *= current;
          break;
        case "/":
          computed = current !== 0 ? computed / current : "Error";
          break;
        default:
          break;
      }
      // Optionally limit float to 4 decimals:
      if (typeof computed === 'number' && !Number.isInteger(computed)) {
        computed = parseFloat(computed.toFixed(4));
      }
      setCalc({ num: computed.toString(), operator: null, result: computed });
    }
  };

  // Whole operation constructor
  const expression = calc.operator
    ? `${calc.result} ${calc.operator} ${calc.num}`
    : calc.num;
    
    useEffect(() => {
      const handleKeyPress = (event) => {
        const key = event.key;

        if (key === "Enter") {
          handleEqual();
        } else if (key === "Backspace") {
          handleClick("C");
        } else if (/\d/.test(key)) {
          handleClick(key);
        } else if (["+", "-", "*", "/"].includes(key)) {
          handleClick(key);
        } else if (key === ".") {
          handleClick(".");
        }
      };


    window.addEventListener("keydown", handleKeyPress);
    return () => {
      window.removeEventListener("keydown", handleKeyPress);
    };
  }, [calc]); // Re-run if calc changes, ensuring the handlers capture the latest state

    // Our calculator menu
  return (
    <div className="calculator">
      <Display input={expression} result={calc.result} />
      <div className="buttonBox">
        {["7", "8", "9", "/",
          "4", "5", "6", "*",
          "1", "2", "3", "-",
          "0", ".", "C", "+"].map((btn, idx) => (
            <button key={idx} onClick={() => handleClick(btn)}>
              {btn}
            </button>
        ))}
        <button className="equal" onClick={handleEqual}>=</button>
      </div>
    </div>
  );
};

export default Calculator;
